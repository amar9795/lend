import java.time.LocalDate;

public class Banking{
    public static void main(String[] args) {
        Bank bank=new Bank();
       /* EMI emi=new EMI(12000,LocalDate.parse("2011-12-10"),7000,5000,100);
        Customer cust=new Customer("Amar", LocalDate.parse("1995-12-02"),"7896541230","abc@gmail.com",30000,"ASE",20000);
        System.out.println( bank.applyLoan(12,12,"HomeLoan",300000,10,"abc",450000,1200,cust));
        System.out.println(bank.applyLoan(12,12,"vehicleloan",1200000,8,"ramu",10000000,450,cust));
//        System.out.println( bank.generateRepaymentSchedule(0));
        System.out.println(bank.RegisterCustomer("Amar", LocalDate.parse("1995-12-02"),"7896541230","abc@gmail.com",30000,"ASE",20000));
       bank.calculatePenaulty(1);*/


    }
}
