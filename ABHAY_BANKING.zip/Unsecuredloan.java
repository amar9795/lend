
public abstract class Unsecuredloan extends Loan {
    public Unsecuredloan(int tenure, int repaymentFrequency, String loanType, double loanAmount, double roi) {
    super(tenure, repaymentFrequency, loanType, loanAmount, roi);
}
}
