public interface Checker {
    void approveRejectLoan(int id);
    void getAllActiveLoanDetails();
    void getLoanDetails(int id);
    public boolean removeLoanAccount(int id);


}
