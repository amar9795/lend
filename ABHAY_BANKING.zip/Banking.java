import java.time.LocalDate;

public class Banking{
    public static void main(String[] args) {
        Bank bank=new Bank();
        Customer cust=new Customer("Amar", LocalDate.parse("1995-12-02"),"7896541230","abc@gmail.com",30000,"ASE",20000);
        System.out.println( bank.applyLoan(12,12,"HomeLoan",300000,10,"abc",450000,1200,cust));
        System.out.println(bank.applyLoan(12,12,"vehicleloan",1200000,8,"ramu",10000000,450,cust));
//        System.out.println( bank.generateRepaymentSchedule(0));


    }
}
