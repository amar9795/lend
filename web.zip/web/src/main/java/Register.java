import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/abc.do")
public class Register extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, NullPointerException{

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        //out.println("<html><body>sjh</body></html>");
        String a=request.getParameter("user_name");
        String b=request.getParameter("user_email");
        String c=request.getParameter("user_password");
        String d=request.getParameter("user_age");
        String e=request.getParameter("user_interest");
        String f=request.getParameter("user_job");
        Connection con=null;
        Statement statement=null;
        try{
            con = DBconnection.createConnection();
            con.setAutoCommit(false);
            statement=con.createStatement();
            PreparedStatement ps = con.prepareStatement("insert into user_r1 values(?,?,?,?,?,?) ");
            ps.setString(1,a);
            ps.setString(2,b);
            ps.setString(3,c);
            ps.setString(4,d);
            ps.setString(5,e);
            ps.setString(6,f);

            int i=ps.executeUpdate();
            if(i>0)
                response.sendRedirect("sucessfull.html");
            con.commit();
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }

}
