import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class DBconnection{

    public static Connection createConnection()
    {
        Connection con = null;
        String url="jdbc:oracle:thin:@10.1.50.198:1521:orcl";
        String username="sh";
        String password="sh";
        try
        {
            try
            {
                Class.forName("oracle.jdbc.driver.OracleDriver");
            }
            catch (ClassNotFoundException e)
            {
                e.printStackTrace();
            }

            con = DriverManager.getConnection(url, username, password);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return con;
    }

//    public static void main(String[] args) {
//        DBconnection db = new DBconnection();
//        db.createConnection();
//    }
}
